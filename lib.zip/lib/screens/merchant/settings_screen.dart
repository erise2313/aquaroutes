import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:aquaroute/screens/auth/login_screen.dart'; // Adjust this path if your login screen is in a different folder!

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final supabase = Supabase.instance.client;
  
  final _jugWeightController = TextEditingController(text: "19");
  final _velocityLimitController = TextEditingController(text: "20");
  
  double _deliveryRadiusMeters = 3000.0; // Default to 3km
  bool _isLoading = true;
  bool _isSaving = false;
  bool _isLoggingOut = false;

  @override
  void initState() {
    super.initState();
    _fetchSystemConfig();
  }

  // 1. Fetch the merchant's current settings from Supabase
  Future<void> _fetchSystemConfig() async {
    try {
      final userId = supabase.auth.currentUser!.id;
      
      final stationData = await supabase
          .from('water_stations')
          .select('delivery_radius_meters')
          .eq('owner_id', userId)
          .maybeSingle();

      if (stationData != null && stationData['delivery_radius_meters'] != null) {
        setState(() {
          _deliveryRadiusMeters = (stationData['delivery_radius_meters'] as num).toDouble();
        });
      }
    } catch (e) {
      debugPrint("Error fetching config: $e");
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  // 2. Save the updated settings back to Supabase
  Future<void> _saveConfig() async {
    setState(() => _isSaving = true);
    try {
      final userId = supabase.auth.currentUser!.id;
      
      await supabase.from('water_stations').update({
        'delivery_radius_meters': _deliveryRadiusMeters,
        // In the future, you can also add columns for jug_weight and velocity_limit here!
      }).eq('owner_id', userId);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Configuration Saved Successfully!"),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Error saving config: $e"), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  // 🛡️ The Secure Supabase Logout Function
  Future<void> _logout() async {
    setState(() => _isLoggingOut = true);

    try {
      await supabase.auth.signOut();
    } catch (e) {
      debugPrint("Server logout failed (likely offline): $e");
    } finally {
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
          (route) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      appBar: AppBar(
        title: const Text(
          "System Configuration",
          style: TextStyle(color: Colors.black87),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black87),
      ),
      body: _isLoading 
          ? const Center(child: CircularProgressIndicator()) 
          : SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // --- NEW: LOGISTICS BOUNDARY CONFIGURATION ---
                  const Text(
                    "Logistics Boundaries",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Maximum Delivery Radius: ${(_deliveryRadiusMeters / 1000).toStringAsFixed(1)} km",
                    style: TextStyle(fontSize: 16, color: Colors.blue.shade700, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  SliderTheme(
                    data: SliderTheme.of(context).copyWith(
                      activeTrackColor: Colors.blue,
                      inactiveTrackColor: Colors.blue.shade100,
                      thumbColor: Colors.blue.shade700,
                      valueIndicatorColor: Colors.blue.shade700,
                    ),
                    child: Slider(
                      value: _deliveryRadiusMeters,
                      min: 1000,   // 1 km minimum
                      max: 15000,  // 15 km maximum
                      divisions: 14,
                      label: "${(_deliveryRadiusMeters / 1000).toStringAsFixed(1)} km",
                      onChanged: (value) {
                        setState(() {
                          _deliveryRadiusMeters = value;
                        });
                      },
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16.0),
                    child: Text(
                      "Customers outside this radius will not see your station in their app.",
                      style: TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                  
                  const SizedBox(height: 32),
                  const Divider(),
                  const SizedBox(height: 24),

                  // --- EXISTING: PAYLOAD MATH ENGINE ---
                  const Text(
                    "Dynamic Payload Math Engine",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 24),

                  _buildFlatTextField(
                    controller: _jugWeightController,
                    label: "Weight per 5-Gallon Jug (kg)",
                    icon: Icons.monitor_weight_outlined,
                  ),
                  const SizedBox(height: 16),

                  _buildFlatTextField(
                    controller: _velocityLimitController,
                    label: "Safety Velocity Limit (kph)",
                    icon: Icons.speed,
                  ),
                  const SizedBox(height: 32),

                  ElevatedButton(
                    onPressed: _isSaving ? null : _saveConfig,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade600,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _isSaving 
                        ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Text(
                            "Save Configuration",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                  ),

                  const SizedBox(height: 48),
                  const Divider(),
                  const SizedBox(height: 24),

                  // The Destructive Action Button
                  OutlinedButton.icon(
                    onPressed: _isLoggingOut ? null : _logout,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.redAccent,
                      side: const BorderSide(color: Colors.redAccent, width: 1.5),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: _isLoggingOut
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(
                              color: Colors.redAccent,
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.logout),
                    label: const Text(
                      "SECURE LOGOUT",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  // Helper widget maintaining the modern flat design system
  Widget _buildFlatTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
  }) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.grey.shade500),
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
      ),
    );
  }
}