import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PlaceOrderScreen extends StatefulWidget {
  const PlaceOrderScreen({super.key});

  @override
  State<PlaceOrderScreen> createState() => _PlaceOrderScreenState();
}

class _PlaceOrderScreenState extends State<PlaceOrderScreen> {
  final supabase = Supabase.instance.client;
  final TextEditingController _jugCountController = TextEditingController();
  
  final LatLng _initialCenter = const LatLng(14.3152, 120.9156);
  GoogleMapController? _mapController;
  
  LatLng? _selectedLocation;
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
  
  bool _isLoading = false;
  bool _isFetchingStations = false;
  
  List<Map<String, dynamic>> _availableStations = [];
  String? _selectedStationId;
  
  // Dynamic Pricing Variables
  double _currentPricePerJug = 0.0;
  double _currentDeliveryFee = 0.0;

  // We no longer fetch stations on initState. We wait for a map tap.
  @override
  void initState() {
    super.initState();
  }

  // Calls our new Supabase RPC to get sorted nearby stations
  Future<void> _fetchNearbyStations(LatLng customerLocation) async {
    setState(() {
      _isFetchingStations = true;
      _availableStations.clear();
      _selectedStationId = null;
      _polylines.clear();
    });

    try {
      final response = await supabase.rpc('get_nearby_stations', params: {
        'user_lat': customerLocation.latitude,
        'user_lng': customerLocation.longitude,
        'radius_meters': 5000 // 5km limit. We can make this dynamic later.
      });
          
      if (mounted) {
        setState(() {
          _availableStations = List<Map<String, dynamic>>.from(response);
          if (_availableStations.isNotEmpty) {
            _selectedStationId = _availableStations.first['id'].toString();
            _updateMapAndPrices(_selectedStationId!);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('No water stations deliver to this area.')),
            );
          }
          _isFetchingStations = false;
        });
      }
    } catch (e) {
      debugPrint("Error fetching nearby stations: $e");
      if (mounted) setState(() => _isFetchingStations = false);
    }
  }

  // Updates pricing, draws lines, arrows, and moves the camera
  void _updateMapAndPrices(String stationId) {
    final station = _availableStations.firstWhere((s) => s['id'].toString() == stationId);
    
    // 1. Update Prices
    setState(() {
      _currentPricePerJug = double.tryParse(station['price_per_jug']?.toString() ?? '40.0') ?? 40.0;
      _currentDeliveryFee = double.tryParse(station['delivery_fee']?.toString() ?? '20.0') ?? 20.0;
    });

    if (_selectedLocation == null || station['station_lat'] == null) return;

    final LatLng stationLocation = LatLng(station['station_lat'], station['station_lng']);

    // 2. Calculate Bearing for the Arrow
    final double bearing = _calculateBearing(_selectedLocation!, stationLocation);
    final LatLng midPoint = _calculateMidpoint(_selectedLocation!, stationLocation);

    // 3. Update Markers and Polylines
    setState(() {
      _markers = {
        Marker(
          markerId: const MarkerId('customer_home'),
          position: _selectedLocation!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          infoWindow: const InfoWindow(title: 'My Delivery Address'),
        ),
        Marker(
          markerId: const MarkerId('selected_station'),
          position: stationLocation,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
          infoWindow: InfoWindow(title: station['station_name']),
        ),
        // The Directional Arrow in the middle of the line
        Marker(
          markerId: const MarkerId('direction_arrow'),
          position: midPoint,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow), 
          // Note: To make this a real arrow, you would use BitmapDescriptor.fromAssetImage here in the future
          rotation: bearing, // Points towards customer
          anchor: const Offset(0.5, 0.5),
        ),
      };

      _polylines = {
        Polyline(
          polylineId: const PolylineId('delivery_route'),
          points: [stationLocation, _selectedLocation!],
          color: Colors.blue.shade700,
          width: 4,
          patterns: [PatternItem.dash(20), PatternItem.gap(10)], // Dotted line effect
        )
      };
    });

    // 4. Adjust Camera to fit both points
    if (_mapController != null) {
      LatLngBounds bounds = LatLngBounds(
        southwest: LatLng(
          min(_selectedLocation!.latitude, stationLocation.latitude),
          min(_selectedLocation!.longitude, stationLocation.longitude)
        ),
        northeast: LatLng(
          max(_selectedLocation!.latitude, stationLocation.latitude),
          max(_selectedLocation!.longitude, stationLocation.longitude)
        )
      );
      _mapController!.animateCamera(CameraUpdate.newLatLngBounds(bounds, 50.0));
    }
  }

  // --- Map Math Helpers ---
  double _calculateBearing(LatLng start, LatLng end) {
    double startLat = start.latitude * pi / 180;
    double startLng = start.longitude * pi / 180;
    double endLat = end.latitude * pi / 180;
    double endLng = end.longitude * pi / 180;

    double dLng = endLng - startLng;
    double y = sin(dLng) * cos(endLat);
    double x = cos(startLat) * sin(endLat) - sin(startLat) * cos(endLat) * cos(dLng);
    double bearing = atan2(y, x) * 180 / pi;
    return (bearing + 360) % 360;
  }

  LatLng _calculateMidpoint(LatLng p1, LatLng p2) {
    return LatLng(
      (p1.latitude + p2.latitude) / 2,
      (p1.longitude + p2.longitude) / 2,
    );
  }
  // ------------------------

  void _onMapTapped(LatLng location) {
    setState(() {
      _selectedLocation = location;
      _markers = {
        Marker(
          markerId: const MarkerId('customer_home'),
          position: location,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
          infoWindow: const InfoWindow(title: 'My Delivery Address'),
        )
      };
      _polylines.clear();
    });
    
    // Fetch nearby stations based on this new pin
    _fetchNearbyStations(location);
  }

  Future<void> _submitOrder() async {
    if (_selectedStationId == null || _selectedLocation == null || _jugCountController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please tap the map and select a station!')));
      return;
    }

    setState(() => _isLoading = true);

    try {
      final customerId = supabase.auth.currentUser!.id;
      final int jugs = int.parse(_jugCountController.text);

      final double calculatedSubtotal = jugs * _currentPricePerJug;
      final double calculatedTotal = calculatedSubtotal + _currentDeliveryFee;

      await supabase.from('orders').insert({
        'station_id': _selectedStationId,
        'customer_id': customerId,
        'delivery_location': 'POINT(${_selectedLocation!.longitude} ${_selectedLocation!.latitude})', 
        'jugs_ordered': jugs,
        'status': 'pending',
        'payment_method': 'cash', 
        'subtotal': calculatedSubtotal,
        'delivery_fee': _currentDeliveryFee,
        'total_amount': calculatedTotal,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Order Placed Successfully! 🎉')),
        );
        setState(() {
          _markers.clear();
          _polylines.clear();
          _selectedLocation = null;
          _jugCountController.clear();
          _availableStations.clear();
        });
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Place Water Order', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue.shade700,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 2,
            child: Stack(
              children: [
                GoogleMap(
                  initialCameraPosition: CameraPosition(target: _initialCenter, zoom: 14.0),
                  markers: _markers,
                  polylines: _polylines,
                  onMapCreated: (controller) => _mapController = controller,
                  onTap: _onMapTapped,
                ),
                Positioned(
                  top: 10, left: 10, right: 10,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    color: Colors.white.withOpacity(0.9),
                    child: const Text('📍 Tap the map to set your delivery address', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                if (_isFetchingStations)
                  const Center(child: CircularProgressIndicator()),
              ],
            ),
          ),
          
          Expanded(
            flex: 2,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedStationId,
                    decoration: const InputDecoration(labelText: '1. Select Nearby Water Station', border: OutlineInputBorder(), prefixIcon: Icon(Icons.storefront)),
                    // Disable the dropdown if no location is picked yet
                    items: _availableStations.isEmpty 
                      ? [const DropdownMenuItem(value: null, child: Text("Tap map to find stations..."))]
                      : _availableStations.map((station) {
                          // Format distance for UI display
                          double dist = double.parse(station['distance'].toString());
                          String distStr = dist > 1000 ? '${(dist/1000).toStringAsFixed(1)} km' : '${dist.toStringAsFixed(0)} m';
                          
                      return DropdownMenuItem<String>(
                        value: station['id'].toString(),
                        child: Text('${station['station_name']} ($distStr away)'),
                      );
                    }).toList(),
                    onChanged: _availableStations.isEmpty ? null : (val) {
                      if (val != null) {
                        setState(() => _selectedStationId = val);
                        _updateMapAndPrices(val); 
                      }
                    },
                  ),
                  
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                    child: Text(
                      'Rates: ₱${_currentPricePerJug.toStringAsFixed(2)}/jug | ₱${_currentDeliveryFee.toStringAsFixed(2)} delivery fee',
                      style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.w600),
                    ),
                  ),
                  
                  const SizedBox(height: 8),
                  
                  TextField(
                    controller: _jugCountController,
                    decoration: const InputDecoration(labelText: '2. Number of Jugs', border: OutlineInputBorder(), prefixIcon: Icon(Icons.water_drop)),
                    keyboardType: TextInputType.number,
                  ),
                  
                  const SizedBox(height: 24),
                  
                  ElevatedButton(
                    onPressed: (_isLoading || _selectedLocation == null) ? null : _submitOrder,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue.shade700, padding: const EdgeInsets.symmetric(vertical: 20)),
                    child: _isLoading 
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text('PLACE ORDER', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}